#ifndef SERVER_H
#define SERVER_H

#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#include "../Library/queue.h"

#define COUNT_PICTURE 5
#define MAX_COUNT_VISITOR 50


// Сравнивает 2 адреса, возвращает 0 еслиони равны, и -1 если не равны
int compare_addr(struct sockaddr_in addr1, struct sockaddr_in addr2)
{
    if ((addr1.sin_addr.s_addr == addr2.sin_addr.s_addr) && (addr1.sin_port == addr2.sin_port) && (addr1.sin_family == addr2.sin_family))
        return 0;
    return 1;
}


struct Server
{
    int port;
    struct sockaddr_in servaddr;
    int sockfd;
    struct sockaddr_in galladdr;                    // адрес клиента галлереи
    int gallerey_connect;
    struct sockaddr_in cliaddr[MAX_COUNT_VISITOR];  // массив, в котором хранятся адреса подключенных клиентов
                                                    // индекс массива используется как ид клиента
    int count_visitor;
    node_t* queues[COUNT_PICTURE]; // очереди к каждой картине, если в очереди к картине в галерее нет места
                                   // то мы здесь храним ид клиента, который хотел подключиться к картине
};

struct Server* init_server(int port, char* ip_address)
{
    struct Server* server = malloc(sizeof (struct Server));
    server->port = port;
    server->count_visitor = 0;
    server->gallerey_connect = 0;
    for(int i = 0; i < COUNT_PICTURE; i++)
    {
        server->queues[i] = NULL;
    }
    // Creating socket file descriptor
    if ( (server->sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&server->servaddr, 0, sizeof(server->servaddr));

    // Filling server information
    server->servaddr.sin_family    = AF_INET; // IPv4
    server->servaddr.sin_addr.s_addr = inet_addr(ip_address);
    server->servaddr.sin_port = htons(server->port);

    // Bind the socket with the server address
    if ( bind(server->sockfd, (const struct sockaddr *)&server->servaddr,
            sizeof(server->servaddr)) < 0 )
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    return server;
}

int get_id_client(struct Server* server, struct sockaddr_in addr)
{
    for(int i = 0; i < MAX_COUNT_VISITOR; i++)
    {
        if (compare_addr(server->cliaddr[i], addr) == 0)
            return i;
    }
    return -1;
}

void send_zero_client(struct Server* server, int client_id)
{
    unsigned int zero = ntohl(0);
    char buffer[4];
    memcpy(buffer, &zero, 4);

    sendto(server->sockfd, (const char *)buffer, sizeof(int), MSG_CONFIRM, (const struct sockaddr *) &server->cliaddr[client_id], sizeof(server->cliaddr[client_id]));
}


#endif // SERVER_H
